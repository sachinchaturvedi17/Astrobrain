(function () {
  "use strict";

  var DEFAULT_PROF = { name: "Sachin Chaturvedi", dob: "2001-01-29", tob: "09:30", city: "Bhopal", gender: "male", palms: null };
  var STATE = {
    lang: localStorage.getItem("am_lang_v09") || "en",
    route: "hub",
    askMode: "muni",
    selectedSign: "Simha",
    calcType: "moon",
    reportTopic: "career",
    drawerOpen: false,
    profileModal: false,
    profile: JSON.parse(localStorage.getItem("am_profile_v09") || "null") || DEFAULT_PROF,
    partner: { name: "Partner", dob: "2002-05-14", tob: "14:20", city: "Indore" },
    panchang: null, horoscope: null, compat: null, calcRes: null, reportRes: null,
    journal: [], article: null, messages: [], panditMsg: ""
  };

  var T = {
    en: {
      hub: "Cosmic hub", ask: "Ask Astromuni", horo: "Horoscope", chart: "My birth chart",
      calc: "Calculators", rep: "Reports", learn: "Learn astrology", pandit: "Talk to Pandit",
      tag: "YOUR PERSONAL COSMIC COMPASS",
      sub: "Understand today's energies, ask what's on your mind, and move forward with timeless Vedic wisdom made personal to you.",
      askBtn: "Ask the universe", chartBtn: "Explore my chart",
      mind: "What's on your mind?", mindSub: "Ask Muni anything. Your answer is interpreted through your unique birth chart.",
      ph: "Tell Astromuni what is on your mind..."
    },
    hg: {
      hub: "Cosmic hub", ask: "Ask Astromuni", horo: "Horoscope", chart: "Meri Kundli",
      calc: "Calculators", rep: "Reports", learn: "Learn astrology", pandit: "Pandit se baat",
      tag: "AAPKA PERSONAL COSMIC COMPASS",
      sub: "Aaj ki grah urja samjhein, apne mann ka sawaal poochein aur Vedic gyan ke saath aage badhein.",
      askBtn: "Ask the universe", chartBtn: "Meri kundli dekhein",
      mind: "Aapke mann mein kya hai?", mindSub: "Muni se kuch bhi poochein. Jawaab aapki janam kundli ke aadhar par milega.",
      ph: "Apna sawaal yahan likhein..."
    },
    hi: {
      hub: "\u0915\u0949\u0938\u094d\u092e\u093f\u0915 \u0939\u092c", ask: "\u090f\u0938\u094d\u091f\u094d\u0930\u094b\u092e\u0941\u0928\u093f \u0938\u0947 \u092a\u0942\u091b\u0947\u0902", horo: "\u0930\u093e\u0936\u093f\u092b\u0932", chart: "\u092e\u0947\u0930\u0940 \u0915\u0941\u0902\u0921\u0932\u0940",
      calc: "\u0915\u0948\u0932\u0915\u0941\u0932\u0947\u091f\u0930", rep: "\u0930\u093f\u092a\u094b\u0930\u094d\u091f\u094d\u0938", learn: "\u091c\u094d\u092f\u094b\u0924\u093f\u0937 \u0938\u0940\u0916\u0947\u0902", pandit: "\u092a\u0902\u0921\u093f\u0924 \u0938\u0947 \u092c\u093e\u0924",
      tag: "\u0906\u092a\u0915\u093e \u0935\u094d\u092f\u0915\u094d\u0924\u093f\u0917\u0924 \u0915\u0949\u0938\u094d\u092e\u093f\u0915 \u0915\u0902\u092a\u093e\u0938",
      sub: "\u0906\u091c \u0915\u0940 \u0917\u094d\u0930\u0939 \u090a\u0930\u094d\u091c\u093e \u0938\u092e\u091d\u0947\u0902 \u0914\u0930 \u0935\u0948\u0926\u093f\u0915 \u091c\u094d\u091e\u093e\u0928 \u0915\u0947 \u0938\u093e\u0925 \u0906\u0917\u0947 \u092c\u0922\u093c\u0947\u0902\u0964",
      askBtn: "Ask the universe", chartBtn: "\u092e\u0947\u0930\u0940 \u0915\u0941\u0902\u0921\u0932\u0940 \u0926\u0947\u0916\u0947\u0902",
      mind: "\u0906\u092a\u0915\u0947 \u092e\u0928 \u092e\u0947\u0902 \u0915\u094d\u092f\u093e \u0939\u0948?", mindSub: "\u092e\u0941\u0928\u093f \u0938\u0947 \u0915\u0941\u091b \u092d\u0940 \u092a\u0942\u091b\u0947\u0902\u0964 \u0909\u0924\u094d\u0924\u0930 \u0906\u092a\u0915\u0940 \u0915\u0941\u0902\u0921\u0932\u0940 \u0915\u0947 \u0906\u0927\u093e\u0930 \u092a\u0930 \u092e\u093f\u0932\u0947\u0917\u093e\u0964",
      ph: "\u0905\u092a\u0928\u093e \u092a\u094d\u0930\u0936\u094d\u0928 \u092f\u0939\u093e\u0901 \u0932\u093f\u0916\u0947\u0902..."
    }
  };

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function postJSON(url, body) {
    return fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {})
    }).then(function (r) { return r.json(); });
  }

  function navItems() {
    var c = T[STATE.lang] || T.en;
    return [
      ["hub", "\u2302", c.hub],
      ["ask", "\u2728", c.ask],
      ["horoscope", "\u2600", c.horo],
      ["chart", "\u2638", c.chart],
      ["calculators", "\u25a6", c.calc],
      ["reports", "\u2630", c.rep],
      ["journal", "\u25a4", c.learn],
      ["pandit", "\u260e", c.pandit]
    ];
  }

  function renderNavButtons() {
    return navItems().map(function (it) {
      var act = STATE.route === it[0] ? " active" : "";
      return '<button type="button" class="am-nbtn' + act + '" data-route="' + it[0] + '"><span>' + it[1] + '</span><span>' + esc(it[2]) + '</span></button>';
    }).join("");
  }

  function renderShell(innerHtml) {
    var c = T[STATE.lang] || T.en;
    var p = STATE.panchang || {};
    var firstName = (STATE.profile.name || "Seeker").split(" ")[0];
    var initials = (STATE.profile.name || "SC").split(" ").map(function (x) { return x[0] || ""; }).join("").slice(0, 2).toUpperCase();
    var rashiLabel = (p.active_rashi_en || "Leo") + " \u2022 " + (p.nakshatra || "Magha");

    var langSeg = ["en", "hg", "hi"].map(function (code) {
      var lbl = code === "en" ? "English" : (code === "hg" ? "Hinglish" : "\u0939\u093f\u0928\u094d\u0926\u0940");
      return '<button type="button" class="' + (STATE.lang === code ? "active" : "") + '" data-set-lang="' + code + '">' + lbl + '</button>';
    }).join("");

    var sideFooter = '<div>' +
      '<div class="am-card" style="padding:12px 14px;margin-bottom:10px;cursor:pointer" data-route="horoscope">' +
      '<div style="font-size:.74rem;color:var(--choc-soft)">Your moon sign</div>' +
      '<div style="font-weight:700;font-size:.9rem;margin-top:2px">' + esc(rashiLabel) + '</div></div>' +
      '<div class="am-card" style="padding:12px 14px;display:flex;align-items:center;gap:10px;cursor:pointer" data-open-prof="1">' +
      '<div style="width:34px;height:34px;border-radius:50%;background:var(--choc);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.82rem">' + esc(initials) + '</div>' +
      '<div><div style="font-weight:700;font-size:.88rem">' + esc(STATE.profile.name) + '</div><div style="font-size:.74rem;color:var(--choc-soft)">Edit birth details</div></div></div></div>';

    var btabs = [
      ["hub", "\u2302", "Cosmic"],
      ["ask", "\u2728", "Ask"],
      ["horoscope", "\u2600", "Horoscope"],
      ["chart", "\u2638", "My"]
    ].map(function (b) {
      var act = STATE.route === b[0] ? " active" : "";
      return '<button type="button" class="am-btab' + act + '" data-route="' + b[0] + '"><span style="font-size:1.05rem">' + b[1] + '</span><span>' + b[2] + '</span></button>';
    }).join("");

    var profModal = !STATE.profileModal ? "" : (
      '<div class="am-modal-bg" id="amProfBg"><div class="am-modal" style="max-width:480px;text-align:left">' +
      '<span class="am-pill">Birth Chart &amp; Optional Palms</span>' +
      '<h2 style="margin-top:8px">Personalise Your Kundli</h2>' +
      '<p style="margin-bottom:14px">Enter your birth details. Palm photos are optional—skip anytime.</p>' +
      '<div class="am-field"><label>Full Name</label><input class="am-input" id="pfName" value="' + esc(STATE.profile.name) + '"></div>' +
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">' +
      '<div class="am-field"><label>Date of Birth</label><input type="date" class="am-input" id="pfDob" value="' + esc(STATE.profile.dob) + '"></div>' +
      '<div class="am-field"><label>Time of Birth</label><input type="time" class="am-input" id="pfTob" value="' + esc(STATE.profile.tob) + '"></div></div>' +
      '<div class="am-field"><label>Birth City</label><input class="am-input" id="pfCity" value="' + esc(STATE.profile.city) + '"></div>' +
      '<div class="am-field"><label>Palm Photos (Optional)</label>' +
      '<input type="file" accept="image/*" id="pfPalm" class="am-input" style="padding:8px">' +
      '<span style="font-size:.8rem;color:var(--choc-soft)">Optional — you can skip uploading palm photos, though adding clear photos helps us give a reading closer to accurate.</span></div>' +
      '<div style="display:flex;gap:10px;justify-content:flex-end;margin-top:16px">' +
      '<button type="button" class="am-btn am-btn-ghost" id="pfSkip">Skip / Close</button>' +
      '<button type="button" class="am-btn" id="pfSave">Save &amp; Update Chart</button></div></div></div>'
    );

    return '<div class="am-shell">' +
      '<aside class="am-side"><div>' +
      '<div class="am-brand" data-route="hub"><div class="am-logo">\u0950</div><div><div class="am-brand-t">astromuni</div><div class="am-brand-s">Wisdom written in the stars</div></div></div>' +
      '<div class="am-nav-lbl">YOUR UNIVERSE</div><nav class="am-nav">' + renderNavButtons() + '</nav></div>' + sideFooter + '</aside>' +
      '<div class="am-drawer-bg' + (STATE.drawerOpen ? "" : " hidden") + '" id="amDrawerBg"><div class="am-drawer"><div>' +
      '<div class="am-brand"><div class="am-logo">\u0950</div><div><div class="am-brand-t">astromuni</div><div class="am-brand-s">Vedic Guidance</div></div></div>' +
      '<nav class="am-nav">' + renderNavButtons() + '</nav></div>' + sideFooter + '</div></div>' +
      '<main class="am-main">' +
      '<header class="am-topbar">' +
      '<div style="display:flex;align-items:center;gap:12px">' +
      '<button type="button" class="am-btn am-btn-ghost" id="amMenuBtn" style="min-height:40px;padding:0 12px">\u2630</button>' +
      '<div><div style="font-weight:700;font-size:.95rem">' + esc(p.date_label || "Sunday, 22 November 2026") + '</div>' +
      '<div style="font-size:.8rem;color:var(--choc-soft)">' + esc((p.tithi || "Shukla Trayodashi") + " \u2022 " + (p.nakshatra || "Ashwini")) + '</div></div></div>' +
      '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">' +
      '<div class="am-seg">' + langSeg + '</div>' +
      '<button type="button" class="am-btn" style="min-height:40px;padding:8px 16px" data-route="ask">\u2728 Ask Muni</button></div></header>' +
      innerHtml + '</main>' +
      '<nav class="am-bnav">' + btabs + '</nav>' + profModal + '</div>';
  }

  function renderHero() {
    var c = T[STATE.lang] || T.en, first = (STATE.profile.name || "Arjun").split(" ")[0];
    return '<div style="display:flex;flex-direction:column;justify-content:center;gap:14px">' +
      '<span class="am-pill" style="align-self:flex-start">' + esc(c.tag) + '</span>' +
      '<h1 style="font-size:clamp(2rem,3.8vw,3rem);line-height:1.12">Good morning, ' + esc(first) + '. <span style="color:#a77824;font-style:italic">Your stars are in motion.</span></h1>' +
      '<p style="color:var(--choc-soft)">' + esc(c.sub) + '</p>' +
      '<div style="display:flex;gap:12px;flex-wrap:wrap"><button type="button" class="am-btn" data-route="ask">' + esc(c.askBtn) + ' &rarr;</button>' +
      '<button type="button" class="am-btn am-btn-ghost" data-route="chart">&#9784; ' + esc(c.chartBtn) + '</button></div></div>';
  }

  function renderWeatherCard() {
    var p = STATE.panchang || {};
    return '<div class="am-card am-card-gold"><div style="display:flex;justify-content:space-between;font-size:.74rem;font-weight:700;color:var(--choc-soft)"><span>YOUR CELESTIAL WEATHER</span><span>&#9679; Live</span></div>' +
      '<div class="am-wheel"><div class="am-wheel-core"><span style="font-size:1.3rem">' + esc(p.active_symbol || "\u264c") + '</span><span style="font-size:.72rem">' + esc((p.active_rashi_en || "LEO").toUpperCase()) + '</span></div></div>' +
      '<div style="display:flex;justify-content:space-between;font-size:.85rem"><span>Energy: <strong>' + esc(p.energy_label || "Radiant & decisive") + '</strong></span><strong>' + esc(p.energy || 82) + '%</strong></div>' +
      '<div class="am-bar"><span style="width:' + esc(p.energy || 82) + '%"></span></div>' +
      '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;font-size:.82rem"><div><div style="color:var(--choc-soft)">Lucky hour</div><strong>' + esc(p.lucky_hour || "10:30 AM") + '</strong></div><div><div style="color:var(--choc-soft)">Guiding</div><strong>' + esc(p.guiding_planet || "Sun") + '</strong></div><div><div style="color:var(--choc-soft)">Focus</div><strong>' + esc(p.focus || "Purpose") + '</strong></div></div></div>';
  }

  function renderHubPrompt() {
    var c = T[STATE.lang] || T.en;
    return '<section class="am-sec am-card"><div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:14px">' +
      '<div><span class="am-pill">PERSONAL GUIDANCE</span><h2 style="margin-top:6px">' + esc(c.mind) + '</h2><p style="color:var(--choc-soft);font-size:.9rem">' + esc(c.mindSub) + '</p></div>' +
      '<div class="am-seg"><button type="button" class="' + (STATE.askMode === "muni" ? "active" : "") + '" data-mode="muni">Muni AI</button><button type="button" class="' + (STATE.askMode === "astropedia" ? "active" : "") + '" data-mode="astropedia">Astropedia</button></div></div>' +
      '<div style="display:flex;gap:10px"><input class="am-input" id="hubAskInput" placeholder="' + esc(c.ph) + '"><button type="button" class="am-btn" id="hubAskSend">&#10148;</button></div>' +
      '<div class="am-chip-row" style="margin-top:12px"><button type="button" class="am-chip" data-quick="What does my career path look like this year?">Career path?</button><button type="button" class="am-chip" data-quick="When is a supportive time for marriage or relationship?">Relationships?</button><button type="button" class="am-chip" data-quick="How is my current Mahadasha shaping my life?">Current Dasha?</button></div></section>';
  }

  function renderHubToolkit() {
    var p = STATE.panchang || {}, pct = (STATE.compat && STATE.compat.percentage) || 86;
    return '<section class="am-sec"><div class="am-sec-hd"><div><span class="am-pill">YOUR VEDIC TOOLKIT</span><h2>Explore the map of you</h2></div></div><div class="am-grid-3">' +
      '<div class="am-card am-card-gold"><span class="am-pill">YOUR CHART</span><h3 style="margin:8px 0 6px">Janam Kundli</h3><p style="font-size:.88rem;color:var(--choc-soft);margin-bottom:14px">Planetary placements, houses, yogas &amp; dashas.</p><button type="button" class="am-btn am-btn-ghost" data-route="chart">Open birth chart &rarr;</button></div>' +
      '<div class="am-card"><span class="am-pill">RELATIONSHIPS</span><h3 style="margin:8px 0 6px">Compatibility</h3><p style="font-size:.88rem;color:var(--choc-soft);margin-bottom:14px">36-point Ashtakoota harmony (' + pct + '% match).</p><button type="button" class="am-btn am-btn-ghost" data-route="compatibility">Check compatibility &rarr;</button></div>' +
      '<div class="am-card"><span class="am-pill">CALENDAR</span><h3 style="margin:8px 0 6px">Today\'s Panchang</h3><div class="am-kv"><span>Tithi</span><strong>' + esc(p.tithi || "Shukla Trayodashi") + '</strong></div><div class="am-kv"><span>Nakshatra</span><strong>' + esc(p.nakshatra || "Ashwini") + '</strong></div><button type="button" class="am-btn am-btn-ghost" style="margin-top:12px" data-route="panchang">Full Panchang &rarr;</button></div></div></section>';
  }
    """;
  }

  function renderHub() {
    var horo = (STATE.horoscope && STATE.horoscope.signs) || [];
    var actH = horo.find(function (s) { return s.key === STATE.selectedSign; }) || horo[0] || {};
    var zcards = horo.map(function (s) {
      return '<button type="button" class="am-zcard' + (s.key === STATE.selectedSign ? " active" : "") + '" data-sign="' + esc(s.key) + '"><span class="am-zicon">' + esc(s.symbol) + '</span><span>' + esc(s.en) + '</span></button>';
    }).join("");
    var calcs = [["moon", "\u263e", "Moon sign", "Find your Rashi."], ["ascendant", "\u2600", "Ascendant", "Rising sign & 1st house."], ["nakshatra", "\u2728", "Nakshatra", "Birth star & Pada."], ["sade_sati", "\u25f4", "Sade Sati", "Saturn's 7.5-yr cycle."]].map(function (x) {
      return '<div class="am-card" style="padding:18px;cursor:pointer" data-calc="' + x[0] + '"><div style="font-size:1.3rem;margin-bottom:8px">' + x[1] + '</div><div class="serif" style="font-weight:700;margin-bottom:4px">' + x[2] + '</div><div style="font-size:.84rem;color:var(--choc-soft)">' + x[3] + '</div></div>';
    }).join("");
    var jcards = (STATE.journal || []).map(function (a) {
      return '<div class="am-card" style="padding:16px;cursor:pointer" data-article="' + esc(a.id) + '"><div class="am-jcover ' + esc(a.theme) + '">' + esc(a.symbol) + '</div><div style="font-size:.7rem;font-weight:700;color:var(--choc-soft);margin-bottom:4px">' + esc(a.category + " \u2022 " + a.read_time) + '</div><div class="serif" style="font-weight:700;margin-bottom:4px">' + esc(a.title) + '</div><div style="font-size:.84rem;color:var(--choc-soft)">' + esc(a.subtitle) + '</div></div>';
    }).join("");
    return '<section class="am-sec am-grid-2">' + renderHero() + renderWeatherCard() + '</section>' + renderHubPrompt() +
      '<section class="am-sec"><div class="am-sec-hd"><div><span class="am-pill">DAILY HOROSCOPE</span><h2>A glimpse of every sign</h2></div></div><div class="am-zodiac-grid" style="margin-bottom:14px">' + zcards + '</div><div class="am-card"><div style="font-size:.74rem;font-weight:700;color:#8c5c19">' + esc((actH.en || "LEO").toUpperCase()) + ' &bull; TODAY</div><h3 style="margin:4px 0 6px">' + esc(actH.headline || "Lead with warmth, not urgency.") + '</h3><p style="color:var(--choc-soft)">' + esc(actH.reading || "") + '</p></div></section>' +
      renderHubToolkit() +
      '<section class="am-sec"><div class="am-sec-hd"><div><span class="am-pill">FREE CALCULATORS</span><h2>Small questions, precise answers</h2></div><button type="button" class="am-btn am-btn-ghost" data-route="calculators">All calculators &rarr;</button></div><div class="am-grid-4">' + calcs + '</div></section>' +
      '<section class="am-sec am-card am-card-dark"><span class="am-pill" style="background:rgba(231,185,73,.2);color:#f7d478">PERSONALISED REPORTS</span><h2 style="margin:10px 0 8px;font-size:1.85rem">Go beyond the daily forecast</h2><p style="color:rgba(255,250,240,.82);max-width:560px;margin-bottom:16px">Astrologer-reviewed readings connecting your chart patterns to the questions that matter now.</p><div class="am-chip-row" style="margin-bottom:16px"><button type="button" class="am-chip" data-rep="career">Career &amp; purpose</button><button type="button" class="am-chip" data-rep="marriage">Love &amp; marriage</button><button type="button" class="am-chip" data-rep="year">Year ahead</button><button type="button" class="am-chip" data-rep="wealth">Wealth path</button></div><button type="button" class="am-btn am-btn-gold" data-route="reports">Explore reports &rarr;</button></section>' +
      '<section class="am-sec"><div class="am-sec-hd"><div><span class="am-pill">ASTROMUNI JOURNAL</span><h2>Wisdom to carry with you</h2></div><button type="button" class="am-btn am-btn-ghost" data-route="journal">Browse journal &rarr;</button></div><div class="am-grid-3">' + jcards + '</div></section>';
  }

  function renderAsk() {
    var c = T[STATE.lang] || T.en, first = (STATE.profile.name || "Seeker").split(" ")[0];
    var msgs = STATE.messages.map(function (m) {
      if (m.role === "user") return '<div class="am-msg-user">' + esc(m.text) + '</div>';
      var steps = (m.steps || []).map(function (s) { return '<li>' + esc(s) + '</li>'; }).join("");
      var proof = (m.proof || []).map(function (p) { return '<div>&bull; ' + esc(p) + '</div>'; }).join("");
      return '<div class="am-msg-ai"><div style="font-size:.74rem;font-weight:700;color:#8c5c19;margin-bottom:4px">' + esc(m.title || "Astromuni's guidance") + '</div><p style="margin-bottom:10px">' + esc(m.answer) + '</p>' +
        (m.window ? '<div style="font-size:.86rem;margin-bottom:8px"><strong>Timing Window:</strong> ' + esc(m.window) + '</div>' : '') +
        (steps ? '<ul style="margin:0 0 10px 18px;padding:0;font-size:.9rem">' + steps + '</ul>' : '') +
        (proof ? '<details style="font-size:.82rem;color:var(--choc-soft)"><summary style="cursor:pointer;font-weight:600">Astrobrain Shastra &amp; Rule Proof</summary><div style="margin-top:6px">' + proof + '</div></details>' : '') + '</div>';
    }).join("");
    return '<div class="am-ask-wrap">' +
      '<div class="am-sage"><div class="am-sage-fig"></div><h3 style="font-size:1.3rem">Astromuni</h3><p style="font-size:.86rem;color:var(--choc-soft);margin-top:4px">Listening to you &bull; Kundli, dashas &amp; live transits active</p></div>' +
      '<div class="am-card"><div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:14px">' +
      '<div><span class="am-pill">TODAY\'S READING</span><h2 style="margin-top:6px">Namaste, ' + esc(first) + '. I\'m here with your chart in front of me.</h2></div>' +
      '<div class="am-seg"><button type="button" class="' + (STATE.askMode === "muni" ? "active" : "") + '" data-mode="muni">Muni AI</button><button type="button" class="' + (STATE.askMode === "astropedia" ? "active" : "") + '" data-mode="astropedia">Astropedia</button></div></div>' +
      '<div class="am-chat-log" id="amChatLog">' + (msgs || '<div class="am-msg-ai"><p style="color:var(--choc-soft)">Ask naturally in English, Hinglish, or Hindi about career, marriage, wealth, Sade Sati, or your current Dasha.</p></div>') + '</div>' +
      '<div class="am-chip-row" style="margin-bottom:10px"><button type="button" class="am-chip" data-askq="How is my career & purpose looking right now?">Career &amp; purpose</button><button type="button" class="am-chip" data-askq="What does my chart say about love and marriage timing?">Love &amp; marriage</button><button type="button" class="am-chip" data-askq="How is my wealth and financial stability shaping up?">Wealth</button><button type="button" class="am-chip" data-askq="Explain my current Mahadasha and Antardasha.">My current dasha</button></div>' +
      '<div style="display:flex;gap:10px"><input class="am-input" id="askMainInput" placeholder="' + esc(c.ph) + '"><button type="button" class="am-btn" id="askMainSend">&#10148;</button></div></div></div>';
  }

  function renderSubpage() {
    var r = STATE.route;
    if (r === "compatibility") {
      var cp = STATE.compat || {};
      var krows = (cp.kootas || []).map(function (k) {
        return '<div class="am-kv"><span><strong>' + esc(k.name) + '</strong> <small style="color:var(--choc-soft)">(' + esc(k.note) + ')</small></span><strong>' + k.obtained + ' / ' + k.max + '</strong></div>';
      }).join("");
      return '<div class="am-sec am-grid-2"><div class="am-card"><span class="am-pill">ASHTAKOOTA GUN MILAN</span><h2 style="margin:8px 0 14px">36-Point Compatibility Check</h2>' +
        '<div class="am-field"><label>Partner Name</label><input class="am-input" id="ptName" value="' + esc(STATE.partner.name) + '"></div>' +
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px"><div class="am-field"><label>Partner DOB</label><input type="date" class="am-input" id="ptDob" value="' + esc(STATE.partner.dob) + '"></div><div class="am-field"><label>Partner Time</label><input type="time" class="am-input" id="ptTob" value="' + esc(STATE.partner.tob) + '"></div></div>' +
        '<div class="am-field"><label>Partner Birth City</label><input class="am-input" id="ptCity" value="' + esc(STATE.partner.city) + '"></div>' +
        '<button type="button" class="am-btn" id="runCompatBtn">Calculate Gun Milan &rarr;</button></div>' +
        '<div class="am-card am-card-gold"><span class="am-pill">MATCH SCORE</span><h2 style="margin:8px 0">' + esc((cp.total_points || 31) + " / 36 Gunas (" + (cp.percentage || 86) + "%)") + '</h2>' +
        '<p style="color:var(--choc-soft);margin-bottom:14px">' + esc(cp.summary || "") + '</p>' + krows + '</div></div>';
    }
    if (r === "calculators") {
      var cr = STATE.calcRes || {};
      var tabs = [["moon", "Moon Sign"], ["ascendant", "Ascendant"], ["nakshatra", "Nakshatra"], ["sade_sati", "Sade Sati"]].map(function (t) {
        return '<button type="button" class="am-chip' + (STATE.calcType === t[0] ? " active" : "") + '" data-calc="' + t[0] + '">' + t[1] + '</button>';
      }).join("");
      var hl = (cr.highlights || []).map(function (h) { return '<div class="am-kv"><span>' + esc(h) + '</span></div>'; }).join("");
      return '<div class="am-card"><span class="am-pill">VEDIC CALCULATORS</span><h2 style="margin:8px 0 14px">Instant Sidereal Calculators</h2><div class="am-chip-row" style="margin-bottom:18px">' + tabs + '</div>' +
        '<div class="am-card am-card-gold"><h3>' + esc(cr.headline || "Moon Sign (Chandra Rashi)") + '</h3><div style="font-size:.86rem;color:#8c5c19;margin:4px 0 10px">' + esc(cr.subline || "") + '</div><p style="margin-bottom:12px">' + esc(cr.summary || "") + '</p>' + hl + '</div></div>';
    }
    if (r === "reports") {
      var rp = STATE.reportRes || {};
      var rtabs = [["career", "Career & Purpose"], ["marriage", "Love & Marriage"], ["year", "Year Ahead"], ["wealth", "Wealth Path"]].map(function (t) {
        return '<button type="button" class="am-chip' + (STATE.reportTopic === t[0] ? " active" : "") + '" data-rep="' + t[0] + '">' + t[1] + '</button>';
      }).join("");
      var rsteps = (rp.steps || []).map(function (s) { return '<li>' + esc(s) + '</li>'; }).join("");
      return '<div class="am-card"><span class="am-pill">PERSONALISED REPORTS</span><h2 style="margin:8px 0 14px">' + esc(rp.title || "Career & Purpose Blueprint") + '</h2><div class="am-chip-row" style="margin-bottom:16px">' + rtabs + '</div>' +
        '<p style="margin-bottom:12px">' + esc(rp.summary || "") + '</p><div class="am-kv"><span>Best Window</span><strong>' + esc(rp.window || "") + '</strong></div><div class="am-kv"><span>Key Rule Basis</span><strong>' + esc(rp.why || "") + '</strong></div><ul style="margin:12px 0 0 18px">' + rsteps + '</ul></div>';
    }
    if (r === "journal") {
      var arts = (STATE.journal || []).map(function (a) {
        var paras = (a.body || []).map(function (p) { return '<p style="margin-top:10px;color:var(--choc-soft)">' + esc(p) + '</p>'; }).join("");
        return '<div class="am-card" style="margin-bottom:16px"><div class="am-jcover ' + esc(a.theme) + '">' + esc(a.symbol) + '</div><span class="am-pill">' + esc(a.category + " \u2022 " + a.read_time) + '</span><h3 style="margin-top:8px;font-size:1.3rem">' + esc(a.title) + '</h3>' + paras + '</div>';
      }).join("");
      return '<div>' + arts + '</div>';
    }
    if (r === "pandit") {
      return '<div class="am-card" style="max-width:640px"><span class="am-pill">LIVE CONSULTATION</span><h2 style="margin:8px 0 6px">Talk to a real pundit</h2><p style="color:var(--choc-soft);margin-bottom:16px">Leave your number and our Vedic Acharya team will arrange your personal session.</p>' +
        '<div class="am-field"><label>Mobile / WhatsApp Number</label><input class="am-input" id="pdPhone" placeholder="+91 98765 43210"></div>' +
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px"><div class="am-field"><label>Preferred Time</label><select class="am-select" id="pdSlot"><option>Morning</option><option>Afternoon</option><option>Evening</option></select></div><div class="am-field"><label>Topic</label><select class="am-select" id="pdTopic"><option>Career</option><option>Marriage &amp; Compatibility</option><option>Finance</option><option>Health &amp; Peace</option></select></div></div>' +
        '<div class="am-field"><label>Anything else? (Optional)</label><textarea class="am-textarea" id="pdNote"></textarea></div>' +
        '<button type="button" class="am-btn" id="pdSubmitBtn">Send request &rarr;</button>' +
        (STATE.panditMsg ? '<p style="margin-top:12px;font-weight:600;color:#2c6e3b">' + esc(STATE.panditMsg) + '</p>' : '') + '</div>';
    }
    var p = STATE.panchang || {}, prof = (STATE.reportRes && STATE.reportRes.profile) || {};
    return '<div class="am-grid-2"><div class="am-card am-card-gold"><span class="am-pill">JANAM KUNDLI &amp; PROFILE</span><h2 style="margin:8px 0 12px">' + esc(STATE.profile.name) + '</h2>' +
      '<div class="am-kv"><span>Birth Details</span><strong>' + esc(STATE.profile.dob + " \u2022 " + STATE.profile.tob + " \u2022 " + STATE.profile.city) + '</strong></div>' +
      '<div class="am-kv"><span>Moon Sign (Rashi)</span><strong>' + esc(prof.rashi || p.active_rashi || "Simha") + '</strong></div>' +
      '<div class="am-kv"><span>Ascendant (Lagna)</span><strong>' + esc(prof.lagna || "Meena") + '</strong></div>' +
      '<div class="am-kv"><span>Nakshatra</span><strong>' + esc(prof.nakshatra || p.nakshatra || "Ashwini") + '</strong></div>' +
      '<div class="am-kv"><span>Active Dasha</span><strong>' + esc((prof.mahadasha || "Jupiter") + " - " + (prof.antardasha || "Mercury")) + '</strong></div>' +
      '<button type="button" class="am-btn" style="margin-top:16px" data-open-prof="1">Edit Birth Chart / Upload Palms</button></div>' +
      '<div class="am-card"><span class="am-pill">TODAY\'S PANCHANG</span><h2 style="margin:8px 0 12px">' + esc(p.date_label || "Today") + '</h2>' +
      '<div class="am-kv"><span>Tithi</span><strong>' + esc(p.tithi || "Shukla Trayodashi") + '</strong></div>' +
      '<div class="am-kv"><span>Nakshatra</span><strong>' + esc(p.nakshatra || "Ashwini") + '</strong></div>' +
      '<div class="am-kv"><span>Yoga &amp; Karana</span><strong>' + esc((p.yoga || "Siddhi") + " / " + (p.karana || "Bava")) + '</strong></div>' +
      '<div class="am-kv"><span>Abhijit Muhurta</span><strong>' + esc(p.abhijit || "11:52 - 12:38") + '</strong></div>' +
      '<div class="am-kv"><span>Rahu Kaal</span><strong>' + esc(p.rahu_kaal || "16:30 - 18:00") + '</strong></div></div></div>';
  }

  function render() {
    var root = document.getElementById("amRoot");
    if (!root) return;
    var view = STATE.route === "hub" ? renderHub() : (STATE.route === "ask" ? renderAsk() : renderSubpage());
    root.innerHTML = renderShell(view);
  }

  function sendQuestion(qText) {
    var q = (qText || "").trim();
    if (!q) return;
    STATE.route = "ask";
    STATE.messages.push({ role: "user", text: q });
    render();
    postJSON("/api/v09/ask", { mode: STATE.askMode, question: q, profile: STATE.profile, lang: STATE.lang }).then(function (res) {
      STATE.messages.push({ role: "ai", title: res.title, answer: res.answer, window: res.window, steps: res.steps, proof: res.proof });
      render();
      var log = document.getElementById("amChatLog");
      if (log) log.scrollTop = log.scrollHeight;
    });
  }

  function refreshAll() {
    Promise.all([
      postJSON("/api/v09/panchang", { city: STATE.profile.city, profile: STATE.profile }),
      postJSON("/api/v09/horoscope", { lang: STATE.lang }),
      postJSON("/api/v09/compatibility", { person_a: STATE.profile, person_b: STATE.partner, lang: STATE.lang }),
      postJSON("/api/v09/calculator", { type: STATE.calcType, profile: STATE.profile, lang: STATE.lang }),
      postJSON("/api/v09/report", { topic: STATE.reportTopic, profile: STATE.profile, lang: STATE.lang }),
      postJSON("/api/v09/journal", {})
    ]).then(function (res) {
      STATE.panchang = res[0];
      STATE.horoscope = res[1];
      STATE.compat = res[2];
      STATE.calcRes = res[3];
      STATE.reportRes = res[4];
      STATE.journal = (res[5] && res[5].articles) || [];
      if (STATE.panchang && STATE.panchang.active_rashi) STATE.selectedSign = STATE.panchang.active_rashi;
      render();
    });
  }

  document.addEventListener("click", function (ev) {
    var t = ev.target;
    var mBtn = t.closest("[data-lang]");
    if (mBtn) {
      STATE.lang = mBtn.getAttribute("data-lang") || "en";
      localStorage.setItem("am_lang_v09", STATE.lang);
      var modal = document.getElementById("amLangModal");
      if (modal) modal.classList.add("hidden");
      refreshAll();
      return;
    }
    var sl = t.closest("[data-set-lang]");
    if (sl) { STATE.lang = sl.getAttribute("data-set-lang"); localStorage.setItem("am_lang_v09", STATE.lang); refreshAll(); return; }
    var rt = t.closest("[data-route]");
    if (rt) { STATE.route = rt.getAttribute("data-route"); STATE.drawerOpen = false; render(); return; }
    if (t.closest("#amMenuBtn")) { STATE.drawerOpen = !STATE.drawerOpen; render(); return; }
    if (t.id === "amDrawerBg") { STATE.drawerOpen = false; render(); return; }
    if (t.closest("[data-open-prof]")) { STATE.profileModal = true; render(); return; }
    if (t.closest("#pfSkip") || t.id === "amProfBg") { STATE.profileModal = false; render(); return; }
    if (t.closest("#pfSave")) {
      STATE.profile.name = (document.getElementById("pfName").value || STATE.profile.name).trim();
      STATE.profile.dob = document.getElementById("pfDob").value || STATE.profile.dob;
      STATE.profile.tob = document.getElementById("pfTob").value || STATE.profile.tob;
      STATE.profile.city = (document.getElementById("pfCity").value || STATE.profile.city).trim();
      localStorage.setItem("am_profile_v09", JSON.stringify(STATE.profile));
      STATE.profileModal = false;
      refreshAll();
      return;
    }
    var md = t.closest("[data-mode]");
    if (md) { STATE.askMode = md.getAttribute("data-mode"); render(); return; }
    var sg = t.closest("[data-sign]");
    if (sg) { STATE.selectedSign = sg.getAttribute("data-sign"); render(); return; }
    var cl = t.closest("[data-calc]");
    if (cl) {
      STATE.calcType = cl.getAttribute("data-calc");
      STATE.route = "calculators";
      postJSON("/api/v09/calculator", { type: STATE.calcType, profile: STATE.profile, lang: STATE.lang }).then(function (r) { STATE.calcRes = r; render(); });
      return;
    }
    var rp = t.closest("[data-rep]");
    if (rp) {
      STATE.reportTopic = rp.getAttribute("data-rep");
      STATE.route = "reports";
      postJSON("/api/v09/report", { topic: STATE.reportTopic, profile: STATE.profile, lang: STATE.lang }).then(function (r) { STATE.reportRes = r; render(); });
      return;
    }
    if (t.closest("[data-article]")) { STATE.route = "journal"; render(); return; }
    var qk = t.closest("[data-quick]");
    if (qk) { sendQuestion(qk.getAttribute("data-quick")); return; }
    var aq = t.closest("[data-askq]");
    if (aq) { sendQuestion(aq.getAttribute("data-askq")); return; }
    if (t.closest("#hubAskSend")) { sendQuestion((document.getElementById("hubAskInput") || {}).value); return; }
    if (t.closest("#askMainSend")) { sendQuestion((document.getElementById("askMainInput") || {}).value); return; }
    if (t.closest("#runCompatBtn")) {
      STATE.partner.name = (document.getElementById("ptName").value || "Partner").trim();
      STATE.partner.dob = document.getElementById("ptDob").value || STATE.partner.dob;
      STATE.partner.tob = document.getElementById("ptTob").value || STATE.partner.tob;
      STATE.partner.city = (document.getElementById("ptCity").value || STATE.partner.city).trim();
      postJSON("/api/v09/compatibility", { person_a: STATE.profile, person_b: STATE.partner, lang: STATE.lang }).then(function (r) { STATE.compat = r; render(); });
      return;
    }
    if (t.closest("#pdSubmitBtn")) {
      STATE.panditMsg = "Request received! Our Vedic Acharya team will reach out shortly.";
      render();
    }
  });

  document.addEventListener("keydown", function (ev) {
    if (ev.key === "Enter" && ev.target && (ev.target.id === "hubAskInput" || ev.target.id === "askMainInput")) {
      ev.preventDefault();
      sendQuestion(ev.target.value);
    }
  });

  render();
  refreshAll();
})();
